
# README_BUILD

Create repo: https://github.com/KenaiBrom/bear-optimizer-pro

Add Secrets: SMTP_USER, SMTP_PASS, PIX_KEY, DISCORD_URL, CERT_PFX, CERT_PFX_PASS

Tag to release: git tag v1.0.0 && git push origin main --tags
