
const expect = require('chai').expect;
describe('License API (skeleton)', ()=> {
  it('should generate and validate a license (demo)', ()=> {
    expect(true).to.equal(true);
  });
});
