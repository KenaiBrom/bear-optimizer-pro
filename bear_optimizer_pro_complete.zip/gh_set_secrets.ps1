
gh secret set PIX_KEY --body "54c2671d-d9da-422b-8ba8-cdd35a8af6e0" --repo "KenaiBrom/bear-optimizer-pro"
gh secret set DISCORD_URL --body "https://discord.gg/y5rX9M8A" --repo "KenaiBrom/bear-optimizer-pro"
gh secret set SMTP_USER --body "bearservice13@gmail.com" --repo "KenaiBrom/bear-optimizer-pro"
# gh secret set SMTP_PASS --body "YOUR_SMTP_PASS" --repo "KenaiBrom/bear-optimizer-pro"
